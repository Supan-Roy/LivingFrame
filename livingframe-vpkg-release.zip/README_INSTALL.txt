================================================================================
LivingFrame — Amazon Fire TV (Vega OS) Application Release Packages
================================================================================

Project: LivingFrame (Intelligent Ambient Room-Aware Media Experience)
Platform: Amazon Vega OS 1.2 / Kepler Framework
Target Devices: Amazon Fire TV & Vega Virtual Device (Emulator)
Package Type: .vpkg (Vega Package — Native compiled application for Vega OS)
Repository: https://github.com/Supan-Roy/LivingFrame

--------------------------------------------------------------------------------
PACKAGE CONTENTS:
--------------------------------------------------------------------------------
1. livingframe_x86_64.vpkg  (3.5 MB)
   -> For official Amazon Vega Virtual Device (Emulator) on x86_64 PC/Mac.

2. livingframe_aarch64.vpkg (3.5 MB)
   -> For physical 64-bit ARM Amazon Fire TV devices running Vega OS.

3. livingframe_armv7.vpkg   (3.5 MB)
   -> For physical 32-bit ARM Amazon Fire TV devices running Vega OS.

--------------------------------------------------------------------------------
QUICK INSTALLATION GUIDE (FOR HACKATHON EVALUATORS):
--------------------------------------------------------------------------------

1. PREREQUISITES:
   - Amazon Vega CLI installed ('vega' command available)
   - A running Vega Virtual Device emulator or connected Fire TV hardware:
     $ vega device list

2. INSTALL TO VEGA VIRTUAL DEVICE (EMULATOR):
   Run:
     $ vega device install livingframe_x86_64.vpkg

3. INSTALL TO PHYSICAL FIRE TV HARDWARE:
   Run:
     $ vega device install livingframe_aarch64.vpkg
     (or livingframe_armv7.vpkg for 32-bit devices)

4. LAUNCH APPLICATION:
   The app will appear on the Fire TV / Vega home screen as "LivingFrame".
   Alternatively, launch via CLI:
     $ vega device launch com.amazondeveloper.livingframe

5. SENSORY BACKGROUND SERVICE (OPTIONAL FOR LIVE VISION SENSING):
   LivingFrame functions with standard Fire TV remote DPAD controls out of the
   box. To enable ambient room vision and spatial hand gestures with your webcam:
     - Clone repository: git clone https://github.com/Supan-Roy/LivingFrame.git
     - Start local WebSocket gateway: node scripts/test_ws_server.js
     - Run camera sensor daemon: python3 scripts/webcam_sensor.py --engine mediapipe

================================================================================
For full architectural details, mathematical foundations, and friction logs,
visit: https://github.com/Supan-Roy/LivingFrame
================================================================================
